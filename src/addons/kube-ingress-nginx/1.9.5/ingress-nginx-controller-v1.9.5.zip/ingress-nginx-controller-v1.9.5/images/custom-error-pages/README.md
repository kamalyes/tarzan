# custom-error-pages

Example of Custom error pages for the Ingress-Nginx Controller
