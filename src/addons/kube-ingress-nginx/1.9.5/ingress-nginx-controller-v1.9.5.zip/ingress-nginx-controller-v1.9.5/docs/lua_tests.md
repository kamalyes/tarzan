# Lua Tests

## Running the Lua Tests

To run the Lua tests you can run the following from the root directory:

```bash
make lua-test
```

This command makes use of docker hence does not need any dependency
installations besides docker

## Where are the Lua Tests?

Lua Tests can be found in the [rootfs/etc/nginx/lua/test](../rootfs/etc/nginx/lua/test) directory


[1]: https://openresty.org/en/installation.html
